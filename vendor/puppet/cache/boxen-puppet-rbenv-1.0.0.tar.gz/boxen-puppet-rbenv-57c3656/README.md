# DEPRECATED

Use [puppet-ruby](https://github.com/boxen/puppet-ruby) instead.
